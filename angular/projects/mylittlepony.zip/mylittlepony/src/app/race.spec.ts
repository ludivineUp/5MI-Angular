import { Race } from './race';

describe('Race', () => {
  it('should create an instance', () => {
    expect(new Race()).toBeTruthy();
  });
});
