import { Pony } from './pony';

describe('Pony', () => {
  it('should create an instance', () => {
    expect(new Pony()).toBeTruthy();
  });
});
