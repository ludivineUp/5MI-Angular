import { MockPonies } from './mock-ponies';

describe('MockPonies', () => {
  it('should create an instance', () => {
    expect(new MockPonies()).toBeTruthy();
  });
});
