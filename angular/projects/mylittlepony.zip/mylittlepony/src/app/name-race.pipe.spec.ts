import { NameRacePipe } from './name-race.pipe';

describe('NameRacePipe', () => {
  it('create an instance', () => {
    const pipe = new NameRacePipe();
    expect(pipe).toBeTruthy();
  });
});
